<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Dosen extends Migration
{
	public function up()
	{
		$this->forge->addField([
            'dos_id' => [
                'type' => 'INT',
                'constraint' => 20,
                'auto_increment' => true,
                'unsigned' => true,
            ],
            'prodi_id' => [
                'type' => 'INT',
                'constraint' => 20,
                'unsigned' => true,
            ],
            'dosen_nama' => [
                'type' => 'VARCHAR',
                'constraint' => 200,
            ],
            'dosen_nik' => [
                'type' => 'INT',
                'constraint' => 30,
            ],
			'dosen_nidn' => [
                'type' => 'INT',
                'constraint' => 30,
            ],
			'dosen_scopus' => [
                'type' => 'INT',
                'constraint' => 30,
            ],
			'dosen_ahli' => [
                'type' => 'VARCHAR',
                'constraint' => 200,
            ],
        ]);

        $this->forge->addKey('dos_id', true);
        $this->forge->addForeignKey('prodi_id', 'prodi', 'prodi_id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('dosen');
		//
	}

	public function down()
	{
		//
	}
}
