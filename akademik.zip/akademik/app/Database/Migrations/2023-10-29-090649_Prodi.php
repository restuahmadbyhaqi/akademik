<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Prodi extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'prodi_id' => [
                'type' => 'INT',
                'constraint' => 20,
                'auto_increment' => true,
                'unsigned' => true,
            ],
            'fak_id' => [
                'type' => 'INT',
                'constraint' => 20,
                'unsigned' => true,
            ],
            'prodi_nama' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
            ],
            'prodi_akre' => [
                'type' => 'CHAR',
                'constraint' => 1,
            ],
            'prodi_jenj' => [
                'type' => 'VARCHAR',
                'constraint' => 5,
            ],
            'prodi_status' => [
                'type' => 'ENUM("Active", "Inactive")',
                'default' => 'Active',
            ],
        ]);
        $this->forge->addKey('prodi_id', true);
        $this->forge->addForeignKey('fak_id', 'fakultas', 'fak_id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('prodi');
    }

    public function down()
    {
        $this->forge->dropTable('prodi');
    }
}
