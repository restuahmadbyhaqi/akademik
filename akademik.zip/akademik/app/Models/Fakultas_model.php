<?php namespace App\Models;

use CodeIgniter\Model;

class Fakultas_model extends Model
{
    protected $table = 'fakultas';
    protected $primaryKey = 'fak_id'; // Sesuaikan dengan nama primary key pada tabel
    protected $allowedFields = ['fak_nama', 'fak_jmlprodi', 'fak_lokasi']; // Tentukan kolom yang diizinkan untuk dimasukkan atau diperbaruiel

    public function getFakultas($id = false)
    {
        if ($id === false) {
            return $this->findAll();
        } else {
            return $this->find($id); // Menggunakan find() untuk mendapatkan data berdasarkan primary key
        }
    }

    public function insertFakultas($data)
    {
        return $this->insert($data);
    }

    public function updateFakultas($id, $data)
{
    $row = $this->find($id);

    if ($row) {
        $updated = $this->where('fak_id', $id)->set($data)->update();

        if ($updated) {
            return true; // Return true jika pembaruan berhasil
        } else {
            return false; // Return false jika terjadi kesalahan saat melakukan pembaruan
        }
    } else {
        return false; // Data tidak ditemukan, tidak ada yang diperbarui
    }
}

    public function deleteFakultas($id)
    {
        return $this->delete($id); // Menggunakan delete() untuk menghapus berdasarkan primary key
    }
}
?>