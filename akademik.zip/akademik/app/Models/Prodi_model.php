<?php

namespace App\Models;

use CodeIgniter\Model;

class Prodi_model extends Model
{
    protected $table = 'prodi';

    public function getProdi($id = false)
    {
        if ($id === false) {
            return $this
                ->join('fakultas', 'fakultas.fak_id = prodi.fak_id')
                ->get()
                ->getResultArray();
        } else {
            return $this
                ->join('fakultas', 'fakultas.fak_id = prodi.fak_id')
                ->where('prodi.prodi_id', $id)
                ->get()
                ->getRowArray();
        }
    }

    public function insertProdi($data)
    {
        return $this->db->table($this->table)->insert($data);
    }

    public function editProdi($id, $data)
    {
        $result = $this->db->table($this->table)
                          ->where('prodi_id', $id)
                          ->update($data);

        return $result ? true : false;
    }

    public function deleteProdi($id)
    {
        $result = $this->db->table($this->table)
                          ->where('prodi_id', $id)
                          ->delete();

        return $result ? true : false;
    }
}
