<?php echo view('_partials/header'); ?>
<?php echo view('_partials/sidebar'); ?>

<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Edit Prodi</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Edit Prodi</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                <form action="<?= base_url('prodi/update/' . $prodi['prodi_id']); ?>" method="post">

                        <div class="card">
                            <div class="card-body">
                                <?php
                                $errors = session()->getFlashdata('errors');
                                if (!empty($errors)) { ?>
                                    <div class="alert alert-danger" role="alert">
                                        Whoops! Ada kesalahan saat input data, yaitu:
                                        <ul>
                                            <?php foreach ($errors as $error) : ?>
                                                <li><?= esc($error) ?></li>
                                            <?php endforeach ?>
                                        </ul>
                                    </div>
                                <?php } ?>

                                <input type="hidden" name="prodi_id" value="<?php echo $prodi['prodi_id']; ?>">

                                <div class="form-group">
                                    <label for="fak_id">Fakultas</label>
                                    <select name="fak_id" class="form-control">
                                        <option value="">Pilih Fakultas</option>
                                        <?php foreach ($datafakultas as $fakultasItem) : ?>
                                            <option value="<?= $fakultasItem['fak_id'] ?>" <?= $fakultasItem['fak_id'] == $prodi['fak_id'] ? 'selected' : '' ?>>
                                                <?= $fakultasItem['fak_nama'] ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="prodi_nama">Nama Prodi</label>
                                    <input type="text" value="<?= $prodi['prodi_nama'] ?>" class="form-control" name="prodi_nama" placeholder="Enter Prodi name">
                                </div>

                                <div class="form-group">
                                    <label for="prodi_akre">Akreditasi</label>
                                    <input type="text" value="<?= $prodi['prodi_akre'] ?>" class="form-control" name="prodi_akre" placeholder="Enter Akreditasi">
                                </div>

                                <div class="form-group">
                                    <label for="prodi_jenj">Jenjang</label>
                                    <input type="text" value="<?= $prodi['prodi_jenj'] ?>" class="form-control" name="prodi_jenj" placeholder="Enter Jenjang">
                                </div>

                                <div class="form-group">
                                    <label for="prodi_status">Status</label>
                                    <select name="prodi_status" class="form-control">
                                        <option value="">Pilih Status</option>
                                        <option value="Active" <?= $prodi['prodi_status'] == "Active" ? 'selected' : '' ?>>Active</option>
                                        <option value="Inactive" <?= $prodi['prodi_status'] == "Inactive" ? 'selected' : '' ?>>Inactive</option>
                                    </select>
                                </div>
                            </div>

                            <div class="card-footer">
                                <a href="<?= base_url('prodi'); ?>" class="btn btn-outline-info">Back</a>
                                <button type="submit" class="btn btn-primary float-right">Update</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo view('_partials/footer'); ?>
