<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Prodi_model;
use App\Models\Fakultas_model;

class Prodi extends Controller
{
    protected $FakultasModel;
    protected $ProdiModel;

    public function __construct()
    {
        $this->FakultasModel = new Fakultas_model();
        $this->ProdiModel = new Prodi_model();
    }

    public function index()
    {
        $data['dataprodi'] = $this->ProdiModel->getProdi();
        $data['datafakultas'] = $this->FakultasModel->getFakultas();
        return view('prodi/index', $data);
    }

    public function create()
    {
        $fakultas = $this->FakultasModel->where('fak_status', 'Active')->findAll();
        $data['fakultas'] = ['' => 'Pilih Fakultas'] + array_column($fakultas, 'fak_nama', 'fak_id');
        return view('prodi/create', $data);
    }

    public function store()
    {
        $validation = \Config\Services::validation();
        $data = [
            'fak_id' => $this->request->getPost('fak_id'),
            'prodi_nama' => $this->request->getPost('prodi_nama'),
            'prodi_akre' => $this->request->getPost('prodi_akre'),
            'prodi_jenj' => $this->request->getPost('prodi_jenj'),
            'prodi_status' => $this->request->getPost('prodi_status'),
        ];

        if ($validation->run($data, 'prodi') == false) {
            session()->setFlashdata('inputs', $this->request->getPost());
            session()->setFlashdata('errors', $validation->getErrors());
            return redirect()->to(base_url('prodi/create'));
        } else {
            $simpan = $this->ProdiModel->insertProdi($data);
            if ($simpan) {
                session()->setFlashdata('success', 'Prodi berhasil dibuat');
                return redirect()->to(base_url('prodi'));
            }
        }
    }

    public function show($id)
    {
        $data['showprodi'] = $this->ProdiModel->getProdi($id);
        echo view('prodi/show', $data);
    }

    public function edit($id)
    {
        $data['prodi'] = $this->ProdiModel->getProdi($id);
        $data['datafakultas'] = $this->FakultasModel->getFakultas();
        echo view('prodi/edit', $data);
    }

    public function update($id)
    {
        $validation = \Config\Services::validation();
        $data = [
            'fak_id' => $this->request->getPost('fak_id'),
            'prodi_nama' => $this->request->getPost('prodi_nama'),
            'prodi_akre' => $this->request->getPost('prodi_akre'),
            'prodi_jenj' => $this->request->getPost('prodi_jenj'),
            'prodi_status' => $this->request->getPost('prodi_status'),
        ];

        if ($validation->run($data, 'prodi') == false) {
            session()->setFlashdata('inputs', $this->request->getPost());
            session()->setFlashdata('errors', $validation->getErrors());
            return redirect()->to(base_url('prodi/edit/' . $id));
        } else {
            $update = $this->ProdiModel->editProdi($id, $data); // Perbaiki parameter $id

            if ($update) {
                session()->setFlashdata('info', 'Updated Prodi successfully');
                return redirect()->to(base_url('prodi'));
            } else {
                session()->setFlashdata('warning', 'Failed to update Prodi');
                return redirect()->to(base_url('prodi/edit/' . $id)); // Redirect kembali ke halaman edit
            }
        }
    }

    public function delete($id)
    {
        $delete = $this->ProdiModel->deleteProdi($id);

        if ($delete) {
            session()->setFlashdata('warning', 'Deleted Prodi successfully');
            return redirect()->to(base_url('prodi'));
        }
    }
}
