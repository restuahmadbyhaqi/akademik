<?php

namespace App\Controllers;

use App\Models\Dashboard_model;

class Dashboard extends BaseController
{
    public function __construct()
    {
        $this->cek_login();
        $this->dashboard_model = new Dashboard_model();
    }

    public function index()
    {
        if ($this->cek_login() === false) {
            session()->setFlashdata('error_login', 'Silahkan login terlebih dahulu untuk mengakses data');
            return redirect()->to('/auth/login');
        }

        $data['total_fakultas'] = $this->dashboard_model->getCountFak();
        $data['total_prodi'] = $this->dashboard_model->getCountProdi();
        $data['total_dosen'] = $this->dashboard_model->getCountDosen();
        $data['total_mahasiswa'] = $this->dashboard_model->getCountMhs();

        echo view('dashboard', $data);
        echo view('_partials/footer');
    }
}
